create definer = eina@`%` view v_workshop_steps as
select `o`.`id`                                     AS `whocall_id`,
       4                                            AS `whocall_type`,
       `p`.`id`                                     AS `id`,
       2                                            AS `object_type`,
       concat('PR-', lpad(`p`.`action_id`, 6, '0')) AS `name`,
       `p`.`created_at`                             AS `date`,
       `o`.`company_id`                             AS `company_id`,
       1                                            AS `orderlist`
from (`eina`.`actions` `o` join `eina`.`actions` `p` on ((`p`.`id` = `o`.`has_budget`)))
where ((`o`.`type_id` = 3) and (`p`.`type_id` = 2));

