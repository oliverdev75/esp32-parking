create definer = eina@`%` view v_acc_group as
select `g`.`id`                                                                        AS `id`,
       `g`.`code`                                                                      AS `code`,
       `g`.`name`                                                                      AS `name`,
       `g`.`type`                                                                      AS `type`,
       `g`.`company_id`                                                                AS `company_id`,
       `g`.`center_id`                                                                 AS `center_id`,
       `c`.`type_FAC`                                                                  AS `type_FAC`,
       (case `g`.`type`
            when 'A' then `c`.`nameA`
            when 'C' then `c`.`nameC`
            when 'T' then `c`.`nameT`
            else 'ERROR' end)                                                          AS `channel_title`,
       max((case when (`c`.`type_title_id` = 1) then `c`.`id` else NULL end))          AS `ventas_id`,
       max((case when (`c`.`type_title_id` = 2) then `c`.`id` else NULL end))          AS `descuentos_id`,
       max((case when (`c`.`type_title_id` = 3) then `c`.`id` else NULL end))          AS `ventasCI_id`,
       max((case when (`c`.`type_title_id` = 4) then `c`.`id` else NULL end))          AS `costeCI_id`,
       max((case when (`c`.`type_title_id` = 5) then `c`.`id` else NULL end))          AS `inventario_id`,
       max((case when (`c`.`type_title_id` = 6) then `c`.`id` else NULL end))          AS `costes_id`,
       max((case when (`c`.`type_title_id` = 1) then `gc`.`acc_number` else NULL end)) AS `Ventas`,
       max((case when (`c`.`type_title_id` = 2) then `gc`.`acc_number` else NULL end)) AS `Descuentos`,
       max((case when (`c`.`type_title_id` = 3) then `gc`.`acc_number` else NULL end)) AS `VentasCI`,
       max((case when (`c`.`type_title_id` = 4) then `gc`.`acc_number` else NULL end)) AS `CosteCI`,
       max((case when (`c`.`type_title_id` = 5) then `gc`.`acc_number` else NULL end)) AS `Inventario`,
       max((case when (`c`.`type_title_id` = 6) then `gc`.`acc_number` else NULL end)) AS `Costes`
from ((`eina`.`account_groups` `g` left join `eina`.`account_gr_ch_num` `gc`
       on ((`gc`.`group_id` = `g`.`id`))) left join `eina`.`account_channels` `c` on ((`c`.`id` = `gc`.`channel_id`)))
group by `g`.`id`, `g`.`code`, `g`.`name`, `g`.`type`, `g`.`company_id`, `g`.`center_id`, `c`.`type_FAC`,
         (case `g`.`type`
              when 'A' then `c`.`nameA`
              when 'C' then `c`.`nameC`
              when 'T' then `c`.`nameT`
              else 'ERROR' end)
order by `c`.`id`;

