create
    definer = eina@`%` procedure sp_log_cli_week(IN pcompany_id int)
BEGIN
        DECLARE last_d DATE;
        DECLARE countlogs INT(4);

        SET @last_d = (SELECT DATE_SUB(CURDATE(), INTERVAL (DAYOFWEEK(CURDATE()) + 6) % 7 DAY));
        SET @countlogs = (SELECT COUNT(*) AS Countrow FROM `logs_client_week` WHERE WEEK = @last_d );
        IF (@countlogs = 0) THEN

            INSERT INTO `logs_client_week` (`week`, `client_id`, `cant_logs`)
            (SELECT @last_d AS WEEK, c.`company_id`, COUNT(l.`id`) AS logscant
            FROM `companies_users` c
            LEFT OUTER JOIN `log` l ON l.`user_id` = c.user_id
            WHERE l.created_at <= @last_d AND l.created_at > DATE_SUB(@last_d, INTERVAL 7 DAY)
            GROUP BY c.`company_id`);

	UPDATE logs_client_week
		INNER JOIN  (SELECT c.`company_id`,  COUNT(a.id) AS actionscant
				FROM `companies_users` c
				LEFT OUTER JOIN `actions` a ON a.`company_id` = c.`company_id`
				WHERE a.created_at <= @last_d AND a.created_at > DATE_SUB(@last_d, INTERVAL 7 DAY)
				GROUP BY c.`company_id`
		)v ON logs_client_week.client_id = v.company_id AND logs_client_week.WEEK = @last_d
		SET logs_client_week.`cant_aux1` = v.actionscant;
        END IF;

        /* SELECT `id`,`week`,`client_id` AS company_id,`cant_logs` FROM logs_client_week WHERE client_id = pcompany_id LIMIT 8; */
        END;

