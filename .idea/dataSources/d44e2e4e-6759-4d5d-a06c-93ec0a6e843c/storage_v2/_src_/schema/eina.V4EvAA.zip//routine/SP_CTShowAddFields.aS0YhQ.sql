create
    definer = eina@`%` procedure SP_CTShowAddFields(IN ccaa char(6), IN company_id char(6), IN general int)
BEGIN
  IF (ccaa = 0) THEN
	SET ccaa = 20 ;
  END IF;

  SELECT
    d.add_general,
    d.`add_content`,
    d.`add_typedoc`,
    d.`add_type`,
    v.`adv_value`,
    d.`add_contentnext`,
    d.id AS design_id,
    v.id AS value_id,
    d.add_order,
    d.add_module_id

  FROM
    `ct_addfield_designs` d
    LEFT JOIN `ct_addfield_values` v
      ON v.`adv_design_id` = d.`id`       AND v.`adv_company_id` = company_id LEFT JOIN `ct_addfield_regions` r
      ON (        r.`id` = d.`add_region_id` AND r.customtemplate = 1 ) OR (d.`add_region_id` = 0 AND r.customtemplate = 0      )
  WHERE d.`add_history` = 0
    AND d.add_type NOT LIKE 'divider'
    AND (
      v.`adv_numdoc` = 0       OR v.`adv_numdoc` IS NULL
    )
    AND (
      d.`add_general` = general       OR general = 0
    )
    AND d.add_module_id = 0
    AND r.id = ccaa
  ORDER BY d.add_typedoc,
    d.`add_order` ;
END;

