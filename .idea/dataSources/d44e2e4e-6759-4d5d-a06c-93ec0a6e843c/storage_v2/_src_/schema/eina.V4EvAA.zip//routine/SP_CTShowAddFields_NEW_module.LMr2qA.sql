create
    definer = eina@`%` procedure SP_CTShowAddFields_NEW_module(IN pregionid char(6), IN pcompany_id char(6),
                                                               IN ptypedoc char(6), IN pshowall char)
BEGIN
IF (pregionid = 0)THEN SET pregionid = 20; END IF;
SELECT d.add_active_from, d.add_typedoc, v.adv_company_id, d.id AS design_id, d.add_general, d.`add_name`, v.`adv_typedoc`, v.`adv_numdoc`, d.`add_history`, d.`add_content`, d.`add_type` ,
 v.`adv_value`, d.`add_contentnext`, v.id AS value_id , d.add_order, d.`add_content_html`, d.`add_contentnext_html` , d.add_module_id
 FROM (
	 SELECT d.* FROM `ct_addfield_designs` d
		LEFT JOIN `ct_addfield_regions` r ON (r.`id` = d.`add_region_id` AND r.customtemplate = 1) OR (d.`add_region_id` = 0 AND r.customtemplate = 0)
		INNER JOIN `mods_companies` c ON   c.company_id = pcompany_id AND c.module_id = d.add_module_id AND c.mod_block = 0

	 WHERE r.id = pregionid AND `add_typedoc` LIKE CAST(ptypedoc AS CHAR) AND add_history = 0
	 ) d
 LEFT JOIN ct_addfield_values v ON d.id = v.`adv_design_id` AND v.`adv_company_id` = pcompany_id AND (v.`adv_numdoc` = 0)

 WHERE (add_showT = 1 AND pshowall = 1) OR (pshowall = 0 AND d.add_type NOT LIKE 'divider') ORDER BY d.add_order, d.add_order;

 END;

