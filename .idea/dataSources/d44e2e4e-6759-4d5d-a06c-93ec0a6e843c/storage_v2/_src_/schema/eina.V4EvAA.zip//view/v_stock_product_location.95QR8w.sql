create definer = eina@`%` view v_stock_product_location as
select `p`.`reference`                                                                                                                                     AS `reference`,
       `p`.`group_discount`                                                                                                                                AS `group_discount`,
       `p`.`id`                                                                                                                                            AS `product_id`,
       `l`.`id`                                                                                                                                            AS `location`,
       `l`.`name`                                                                                                                                          AS `loc_name`,
       (case
            when isnull(((case when isnull(`r`.`store_reserved`) then 0 else `r`.`store_reserved` end) + (case
                                                                                                              when (
                                                                                                                  (`v`.`physical` -
                                                                                                                   (case
                                                                                                                        when isnull(`r`.`total_reserved`)
                                                                                                                            then 0
                                                                                                                        else `r`.`total_reserved` end)) <
                                                                                                                  0)
                                                                                                                  then 0
                                                                                                              else (
                                                                                                                  `v`.`physical` -
                                                                                                                  (case
                                                                                                                       when isnull(`r`.`total_reserved`)
                                                                                                                           then 0
                                                                                                                       else `r`.`total_reserved` end)) end)))
                then 0
            else ((case when isnull(`r`.`store_reserved`) then 0 else `r`.`store_reserved` end) + (case
                                                                                                       when (
                                                                                                           (`v`.`physical` -
                                                                                                            (case
                                                                                                                 when isnull(`r`.`total_reserved`)
                                                                                                                     then 0
                                                                                                                 else `r`.`total_reserved` end)) <
                                                                                                           0) then 0
                                                                                                       else (
                                                                                                           `v`.`physical` -
                                                                                                           (case
                                                                                                                when isnull(`r`.`total_reserved`)
                                                                                                                    then 0
                                                                                                                else `r`.`total_reserved` end)) end)) end) AS `physical`,
       (case
            when isnull(`v`.`physical`) then 0
            else (case
                      when isnull(`r`.`total_reserved`) then `v`.`physical`
                      else (case
                                when ((`v`.`physical` - `r`.`total_reserved`) < 0) then 0
                                else (`v`.`physical` - `r`.`total_reserved`) end) end) end)                                                                AS `disp`,
       (case
            when isnull(`o`.`total_quantity`) then 0
            else `o`.`total_quantity` end)                                                                                                                 AS `engaged`,
       (case
            when isnull(`r`.`product_id`) then 0
            else `r`.`total_reserved` end)                                                                                                                 AS `reserved`,
       (case when isnull(`f`.`fault`) then 0 else `f`.`fault` end)                                                                                         AS `fault`,
       `v`.`last_in`                                                                                                                                       AS `last_in`,
       `v`.`last_out`                                                                                                                                      AS `last_out`,
       `l`.`store_id`                                                                                                                                      AS `store_id`,
       `s`.`name`                                                                                                                                          AS `store_name`,
       `s`.`bookmark`                                                                                                                                      AS `bookmark`,
       `s`.`lordicon`                                                                                                                                      AS `lordicon`,
       `s`.`company_id`                                                                                                                                    AS `company_id`,
       `s`.`center_id`                                                                                                                                     AS `center_id`
from ((((((`eina`.`products` `p` join `eina`.`locations` `l`
           on ((`l`.`company_id` = `p`.`company_id`))) left join `eina`.`stores` `s`
          on (((`s`.`id` = `l`.`store_id`) and (`l`.`company_id` = `s`.`company_id`)))) left join (select `m`.`company_id`                                                        AS `company_id`,
                                                                                                          `m`.`product_id`                                                        AS `product_id`,
                                                                                                          (case when (`m`.`loc_in` = 0) then `m`.`loc_out` else `m`.`loc_in` end) AS `location`,
                                                                                                          `l`.`name`                                                              AS `loc_name`,
                                                                                                          (case
                                                                                                               when isnull(sum(`m`.`quanti_in`))
                                                                                                                   then 0
                                                                                                               else sum(`m`.`quanti_in`) end)                                     AS `totIng`,
                                                                                                          (case
                                                                                                               when isnull(sum(`m`.`quanti_out`))
                                                                                                                   then 0
                                                                                                               else sum(`m`.`quanti_out`) end)                                    AS `totSal`,
                                                                                                          (case
                                                                                                               when isnull(sum((`m`.`quanti_in` - `m`.`quanti_out`)))
                                                                                                                   then 0
                                                                                                               else sum((`m`.`quanti_in` - `m`.`quanti_out`)) end)                AS `physical`,
                                                                                                          max((case when (`m`.`loc_in` = 0) then '' else `m`.`created_at` end))   AS `last_in`,
                                                                                                          max((case when (`m`.`loc_out` = 0) then '' else `m`.`created_at` end))  AS `last_out`,
                                                                                                          `s`.`id`                                                                AS `store_id`,
                                                                                                          `s`.`name`                                                              AS `store_name`,
                                                                                                          `s`.`bookmark`                                                          AS `bookmark`,
                                                                                                          `s`.`lordicon`                                                          AS `lordicon`
                                                                                                   from ((`eina`.`rec_products_mov` `m` left join `eina`.`locations` `l`
                                                                                                          on ((
                                                                                                              ((`l`.`id` = `m`.`loc_in`) or (`l`.`id` = `m`.`loc_out`)) and
                                                                                                              (`l`.`company_id` = `m`.`company_id`)))) left join `eina`.`stores` `s`
                                                                                                         on (((`s`.`id` = `l`.`store_id`) and (`l`.`company_id` = `s`.`company_id`))))
                                                                                                   group by `m`.`company_id`,
                                                                                                            `m`.`product_id`,
                                                                                                            `l`.`name`,
                                                                                                            `s`.`id`,
                                                                                                            `s`.`name`,
                                                                                                            `s`.`bookmark`,
                                                                                                            `s`.`lordicon`,
                                                                                                            (case when (`m`.`loc_in` = 0) then `m`.`loc_out` else `m`.`loc_in` end)) `v`
         on (((`v`.`location` = `l`.`id`) and (`v`.`product_id` = `p`.`id`)))) left join (select `r`.`product_id`                                                   AS `product_id`,
                                                                                                 sum((case
                                                                                                          when isnull(`f`.`quantity`)
                                                                                                              then 0
                                                                                                          else (`f`.`quantity` - `f`.`received`) end))              AS `fautls_received`,
                                                                                                 (case
                                                                                                      when isnull(sum((`r`.`quant_reserved` - `r`.`quant_delivered`)))
                                                                                                          then 0
                                                                                                      else sum((`r`.`quant_reserved` - `r`.`quant_delivered`)) end) AS `total_reserved`,
                                                                                                 (case
                                                                                                      when isnull(sum(`r`.`quant_available`))
                                                                                                          then 0
                                                                                                      else sum(`r`.`quant_available`) end)                          AS `store_reserved`,
                                                                                                 `r`.`location_id`                                                  AS `location`
                                                                                          from (`eina`.`reservations` `r` left join `eina`.`or_faults` `f`
                                                                                                on (((`f`.`id` = `r`.`fault_id`) and (`f`.`requested` = 1))))
                                                                                          where ((`r`.`quant_reserved` - `r`.`quant_delivered`) > 0)
                                                                                          group by `r`.`product_id`, `r`.`location_id`) `r`
        on (((`r`.`location` = `l`.`id`) and (`r`.`product_id` = `p`.`id`)))) left join (select `f`.`location`                                                                       AS `location`,
                                                                                                `f`.`product_id`                                                                     AS `product_id`,
                                                                                                sum((case
                                                                                                         when isnull(`f`.`quantity`)
                                                                                                             then 0
                                                                                                         else (case when (`f`.`requested` = 0) then `f`.`quantity` else 0 end) end)) AS `fault`
                                                                                         from `eina`.`or_faults` `f`
                                                                                         group by `f`.`product_id`, `f`.`location`) `f`
       on (((`f`.`location` = `l`.`id`) and (`f`.`product_id` = `p`.`id`)))) left join (select `p`.`product_id`      AS `product_id`,
                                                                                               sum(`p`.`pend_quant`) AS `total_quantity`,
                                                                                               `p`.`location`        AS `location`
                                                                                        from `eina`.`orders_products` `p`
                                                                                        group by `p`.`product_id`, `p`.`location`) `o`
      on (((`o`.`location` = `l`.`id`) and (`o`.`product_id` = `p`.`id`))))
where ((`l`.`deleted` = 0) and (`s`.`deleted` = 0) and (`p`.`deleted` = 0) and (`p`.`company_id` = `s`.`company_id`));

