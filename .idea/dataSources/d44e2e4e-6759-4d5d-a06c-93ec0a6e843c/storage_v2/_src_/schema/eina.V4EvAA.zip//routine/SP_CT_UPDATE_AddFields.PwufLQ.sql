create
    definer = eina@`%` procedure SP_CT_UPDATE_AddFields(IN pregion_id int, IN pcompany_id char(6), IN pgeneral int,
                                                        IN pnumdoc int, IN pdesign_id int, IN pvalue_NEW char(255))
BEGIN
    INSERT INTO `ct_addfield_designs` (`add_region_id`, `add_general`, `add_typedoc`, `add_content`, `add_contentnext`, `add_type`, `add_name`, `add_order`, `add_history`, `created_at`, `updated_at`, `add_content_html`, `add_contentnext_html`, `add_showT`, `add_showTemplate`,`add_active_from`,`add_module_id`)
        ( SELECT `add_region_id`, `add_general`,`add_typedoc`,`add_content`,`add_contentnext`,`add_type`,`add_name`,`add_order`,`add_history`, CURDATE(),`updated_at`,`add_content_html`,`add_contentnext_html` , `add_showT`, `add_showTemplate`,`add_active_from`,`add_module_id` FROM ct_addfield_designs WHERE id = pdesign_id );
    SET @lastId = (SELECT id FROM ct_addfield_designs WHERE `add_region_id` = pregion_id AND add_general = pgeneral ORDER BY id DESC LIMIT 1);

    IF pvalue_NEW IS NOT NULL THEN
        INSERT INTO `ct_addfield_values` (`adv_company_id`,`adv_typedoc`,`adv_numdoc`,`adv_design_id`,`adv_value`,`created_at`)
        (SELECT pcompany_id, `add_typedoc`, pnumdoc, id, pvalue_NEW, CURDATE() FROM ct_addfield_designs WHERE id = @lastId );
    END IF;
    UPDATE `ct_addfield_designs` SET `add_history` = 1, `updated_at` = CURDATE() WHERE `id` = pdesign_id;
    END;

