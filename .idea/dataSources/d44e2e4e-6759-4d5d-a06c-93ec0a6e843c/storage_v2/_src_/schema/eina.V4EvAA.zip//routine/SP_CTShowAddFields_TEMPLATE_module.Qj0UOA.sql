create
    definer = eina@`%` procedure SP_CTShowAddFields_TEMPLATE_module(IN pregionid char(6), IN pcompany_id char(6),
                                                                    IN ptypedoc char(6), IN pnumdoc int)
BEGIN IF (pregionid = 0)THEN SET pregionid = 20; END IF;
SELECT add_order, design_id, add_general, `add_name`,`add_typedoc`, `add_history`, `add_type` , `add_content`, adv_numdoc ,
	CASE WHEN (`add_type` LIKE 'date%' AND adv_value IS NOT NULL) THEN DATE_FORMAT(adv_value, '%d/%m/%Y') ELSE adv_value END AS adv_value, `add_contentnext`, value_id, `add_content_html`, `add_contentnext_html`
	,add_module_id
FROM(
 SELECT d.add_order, d.id AS design_id, d.add_general, d.`add_name`,d.`add_typedoc`, d.`add_history`, d.`add_type` , d.`add_content`, CASE WHEN vc.`adv_numdoc` IS NULL THEN vg.adv_numdoc ELSE vc.`adv_numdoc` END AS adv_numdoc ,
	CASE WHEN vc.`adv_value` IS NULL THEN vg.adv_value ELSE vc.`adv_value` END AS adv_value , d.`add_contentnext`, CASE WHEN vc.`id` IS NULL THEN vg.id ELSE vc.`id` END AS value_id, d.`add_content_html`, d.`add_contentnext_html`
	,d.add_module_id

 FROM `ct_addfield_designs` d
	LEFT JOIN `ct_addfield_regions` r ON (r.`id` = d.`add_region_id` AND r.customtemplate = 1) OR (d.`add_region_id` = 0 AND r.customtemplate = 0)
	INNER JOIN `mods_companies` c ON   c.company_id = pcompany_id AND c.module_id = d.add_module_id AND c.mod_block = 0
	LEFT JOIN ct_addfield_values vg ON d.id = vg.`adv_design_id` AND vg.`adv_company_id` = pcompany_id AND (vg.`adv_numdoc` = 0)
	LEFT JOIN ct_addfield_values vc ON d.id = vc.`adv_design_id` AND vc.`adv_company_id` = pcompany_id AND (vc.`adv_numdoc` = pnumdoc)
 WHERE d.add_module_id > 0 AND r.id = pregionid AND d.`add_typedoc` LIKE CAST(ptypedoc AS CHAR) AND d.add_history = 0 AND d.add_type NOT LIKE 'divider' AND `add_showTemplate` = 1

 ) V

 ORDER BY add_order; END;

