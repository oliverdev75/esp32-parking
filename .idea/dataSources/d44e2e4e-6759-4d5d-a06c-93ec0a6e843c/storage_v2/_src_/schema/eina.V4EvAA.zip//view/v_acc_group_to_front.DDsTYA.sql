create definer = eina@`%` view v_acc_group_to_front as
select `v_acc_group`.`id`            AS `id`,
       `v_acc_group`.`code`          AS `code`,
       `v_acc_group`.`name`          AS `name`,
       `v_acc_group`.`type`          AS `type`,
       `v_acc_group`.`company_id`    AS `company_id`,
       `v_acc_group`.`center_id`     AS `center_id`,
       `v_acc_group`.`type_FAC`      AS `type_FAC`,
       `v_acc_group`.`channel_title` AS `channel_title`,
       `v_acc_group`.`ventas_id`     AS `ventas_id`,
       `v_acc_group`.`descuentos_id` AS `descuentos_id`,
       `v_acc_group`.`ventasCI_id`   AS `ventasCI_id`,
       `v_acc_group`.`costeCI_id`    AS `costeCI_id`,
       `v_acc_group`.`inventario_id` AS `inventario_id`,
       `v_acc_group`.`costes_id`     AS `costes_id`,
       `v_acc_group`.`Ventas`        AS `Ventas`,
       `v_acc_group`.`Descuentos`    AS `Descuentos`,
       `v_acc_group`.`VentasCI`      AS `VentasCI`,
       `v_acc_group`.`CosteCI`       AS `CosteCI`,
       `v_acc_group`.`Inventario`    AS `Inventario`,
       `v_acc_group`.`Costes`        AS `Costes`
from `eina`.`v_acc_group`
where (`v_acc_group`.`channel_title` is not null);

